<?php
$host ="localhost";
$username ="root";
$password ="";
$DBname ="mydb";

$mysqli = new mysqli($host, $username, $password, $DBname);

?>
